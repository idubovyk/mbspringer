/*
 * Compile without GPU support:
 *   c++ -std=c++11 -pthread -I../src 2_complex_demo.cpp -o 2_complex_demo.out -lgsl -lgslcblas
 * Compile with GPU support:
 *   nvcc -arch=<arch> -std=c++11 -x cu -Xptxas -O0 -Xptxas --disable-optimizer-constants -I../src 2_complex_demo.cpp -o 2_complex_demo.out -lgsl -lgslcblas
 * Here `<arch>` is the architecture of the target GPU or `compute_30` if you are happy to use Just-in-Time compilation (See the Nvidia `nvcc` manual for more details).
 */

#include <iostream>
#include <limits> // numeric_limits
#include "qmc.hpp"

#include <complex>
typedef std::complex<double> complex_t;

extern "C" complex_t integrand_(double* x);

struct my_functor_t {
    const unsigned long long int number_of_integration_variables = 3;
#ifdef __CUDACC__
    __host__ __device__
#endif

    complex_t operator()(double* x) const
    {
		complex_t gint;
     	gint = integrand_(x);
		return gint;
    }
} my_functor;

int main() {

    const unsigned int MAXVAR = 3;
    
    integrators::Qmc<complex_t,double,MAXVAR,integrators::transforms::Korobov<3>::type,integrators::fitfunctions::None::type> integrator;
    integrator.verbosity = 3;
    integrator.cputhreads = 1;
    integrator.epsrel = 1e-10;
    integrator.epsabs  = 1e-10; // requested absolute accuracy
    integrator.minn = 100000;
    integrator.maxeval = 10000000; // maximum number of function evaluations
    integrator.minm = 32;
//    integrator.evaluateminn = 100000;
    integrators::result<complex_t> result = integrator.integrate(my_functor);
    std::cout.precision(17);
    std::cout << "integral = " << std::fixed << result.integral << std::endl;
    std::cout << "error    = " << result.error    << std::endl;

    return 0;
}
